package com;

public abstract class PaymentService {
    public abstract void getPaymentStatus();
    public abstract void getPaymentMethod();
}
